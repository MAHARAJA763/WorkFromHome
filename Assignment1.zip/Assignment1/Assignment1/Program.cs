﻿using System;
using System.Data.SqlClient;

namespace Assignment1
{
    class Program
    {
        int choice;
        
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Start();
        }

        public void Start()
        {
            Console.WriteLine("What you want to do?");
            Console.WriteLine("1.Login \n 2.Signup \n 3.Exit");
            choice = Convert.ToInt32(Console.ReadLine());
            Start start = new Start();
            switch (choice)
            {
                case 1:
                    start.Login();
                    Start();
                    break;

                case 2:
                    start.Signup();
                    Start();
                    break;
                case 3:
                    Environment.Exit(-1);
                    break;

                default:
                    Console.WriteLine("Invalid Choice");
                    Start();
                    break;
            }
        }

       
        
    }

    
}
