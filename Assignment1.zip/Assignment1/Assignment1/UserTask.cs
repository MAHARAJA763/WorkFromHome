﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment1
{
    class UserTask:BaseContext
    {
        User User = new User();
        public void ViewDetail(int userId)
        {
            User.UserId = userId;
            var reader = GetReader($"select * from Students where StudentId = {User.UserId}");
            while (reader.Read())
            {
                User.UserName = reader.GetString(1);
                User.ContactNumber = reader.GetString(3);
                User.Address = reader.GetString(4);
                Console.WriteLine($"UserName : {User.UserName} ContactNumber : {User.ContactNumber} Address : {User.Address }");
            }
        }
        public void UpdateDetail(int UserId)
        {
            Console.WriteLine("Enter new User Name:");
            User.UserName = Console.ReadLine();
            ExecuteNonQuery($"update Users set UserName='{User.UserName}' where userId='{UserId}'");
        }
        public void Delete(int userId)
        {
            User.UserId = userId;
            ExecuteNonQuery($"delete from Users where UserId = {User.UserId}");
        }
    }
}
