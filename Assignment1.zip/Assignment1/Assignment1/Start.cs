﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment1
{
    class Start:BaseContext
    {

        
        Program program = new Program();
        int userId;
       public Start()
        {
           
            
        }
        public void Login()
        {
            User user = new User();
            Console.WriteLine("Enter UserName:");
            user.UserName = Console.ReadLine();
            Console.WriteLine("Enter Password:");            
            user.Password = Console.ReadLine();

            var reader = this.GetReader($"select * from users where userName={user.UserName} and password={user.Password}");
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    user.UserId = reader.GetInt32(0);
                    userId = user.UserId;
                }
            }
            else
            {
                Console.WriteLine("Invalid Credentials!!!");
                program.Start();
            }
            reader.Close();
            CloseConnection();
        }
        public void Signup()
        {
            User user = new User();
            Console.WriteLine("Enter UserName");
            user.UserName = Console.ReadLine();

            Console.WriteLine("Enter ContactNumber:");
            user.ContactNumber = Console.ReadLine();

            Console.WriteLine("Enter Date Of Birth(YYYY/MM/DD)");
            user.DateOfBirth =Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Enter Address");
            user.Address = Console.ReadLine();


            Console.WriteLine("Enter Email");
            user.Email = Console.ReadLine();

            Console.WriteLine("Enter Gender(Male/Female)");
            user.Gender = Console.ReadLine();

            ExecuteNonQuery($"insert into Users(UserName,ContactNumber,DateOfBirth,Address,Email,Gender)values('{user.UserName}','{user.ContactNumber}','{user.DateOfBirth}','{user.Address}','{user.Email}','{user.Gender}')");
            Console.WriteLine("Register SuccessFUL!!!");
            program.Start();
        }
        void AfterLogin()
        {
            int userChoice;
            Console.WriteLine("What You want to do... \n 1.View User Detail \n 2.Update UserName \n 2.Delete Profile \n 2.Logout");
            userChoice = Convert.ToInt32(Console.ReadLine());
            UserTask userTask = new UserTask();
            switch (userChoice)
            {
             
                case 1:
                    userTask.ViewDetail(userId);
                    AfterLogin();
                    break;

                case 2:
                    userTask.UpdateDetail(userId);
                    AfterLogin();
                    break;
                case 3:
                    userTask.Delete(userId);
                    AfterLogin();
                    break;
                case 4:
                    program.Start();
                    break;

                default:
                    Console.WriteLine("Invalid Choice");
                    AfterLogin();
                    break;
            }
        
        }
    }
}
