﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment2
{
    class Publisher
    {
        public int PublisherId { get; set; }
        public string PublisherName { get; set; }
        public string PublisherWebsite { get; set; }
    }
}
