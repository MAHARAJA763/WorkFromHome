﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Assignment2
{
    class Program
    {
        int choice;
        
        static void Main(string[] args)
        {
            vGame vGame = new vGame();
            Console.WriteLine(vGame);
            Program p = new Program();
            p.Start();

        }

        public void Start()
        {
            Start start = new Start();
            Console.WriteLine("What you want to do");
            Console.WriteLine("1.View All Games \n 2.Game By Category \n 3.Search Game \n 4.Exit");
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    start.viewAll();
                    Start();
                    break;

                case 2:
                    start.GameByCategory();
                    Start();
                    break;
                case 3:
                    //Search();
                    Start();
                    break;

                case 4:
                    Environment.Exit(-1);
                    Start();
                    break;

                case 5:
                    break;

                default:
                    Console.WriteLine("Invalid Choice");
                    Start();
                    break;
            }
        }

    }


}
