﻿using Assignment1;
using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment2
{
    class Start:BaseContext
    {
        public void viewAll()
        {
            vGame vGame = new vGame();
            var reader = GetReader("select * from vGames");
            while (reader.Read())
            {
                vGame.GameName = reader.GetString(0);
                vGame.PublisherName = reader.GetString(1);
                vGame.PublisherWebsite = reader.GetString(2);
                vGame.CategoryName = reader.GetString(3);
                vGame.RatingType = reader.GetString(4);
            }
            reader.Close();
            CloseConnection();
            Console.WriteLine($"GameName:{vGame.GameName} \n PublisherName:{vGame.PublisherName} \n Website:{vGame.PublisherWebsite} \n Category:{vGame.CategoryName} \n Rating:{vGame.RatingType}");
        }
        public void GameByCategory()
        {
            int category;
            vGame vGame = new vGame();
            Program program = new Program();
            Console.WriteLine("Choose Game Category:\n 1.Arcade \n 2.Action \n 3.Adventure \n 4.Puzzle \n 5.Crime");
            category = Convert.ToInt32(Console.ReadLine());
            switch (category)
            {
                case 1:
                    var reader = GetReader("select * from vGames where CategoryName=Arcade");
                    while (reader.Read())
                    {
                        vGame.GameName = reader.GetString(0);
                        vGame.PublisherName = reader.GetString(1);
                        vGame.PublisherWebsite = reader.GetString(2);
                        vGame.CategoryName = reader.GetString(3);
                        vGame.RatingType = reader.GetString(4);
                    }
                    reader.Close();
                    CloseConnection();
                    Console.WriteLine($"GameName:{vGame.GameName} \n PublisherName:{vGame.PublisherName} \n Website:{vGame.PublisherWebsite} \n Category:{vGame.CategoryName} \n Rating:{vGame.RatingType}");
                    program.Start();
                    break;

                case 2:
                    reader = GetReader("select * from vGames where CategoryName=Action");
                    while (reader.Read())
                    {
                        vGame.GameName = reader.GetString(0);
                        vGame.PublisherName = reader.GetString(1);
                        vGame.PublisherWebsite = reader.GetString(2);
                        vGame.CategoryName = reader.GetString(3);
                        vGame.RatingType = reader.GetString(4);
                    }
                    reader.Close();
                    CloseConnection();
                    Console.WriteLine($"GameName:{vGame.GameName} \n PublisherName:{vGame.PublisherName} \n Website:{vGame.PublisherWebsite} \n Category:{vGame.CategoryName} \n Rating:{vGame.RatingType}");
                    program.Start();
                    break;
                case 3:
                    reader = GetReader("select * from vGames where CategoryName=Adventure");
                    while (reader.Read())
                    {
                        vGame.GameName = reader.GetString(0);
                        vGame.PublisherName = reader.GetString(1);
                        vGame.PublisherWebsite = reader.GetString(2);
                        vGame.CategoryName = reader.GetString(3);
                        vGame.RatingType = reader.GetString(4);
                    }
                    reader.Close();
                    CloseConnection();
                    Console.WriteLine($"GameName:{vGame.GameName} \n PublisherName:{vGame.PublisherName} \n Website:{vGame.PublisherWebsite} \n Category:{vGame.CategoryName} \n Rating:{vGame.RatingType}");
                    program.Start();
                    break;

                case 4:
                    reader = GetReader("select * from vGames where CategoryName=Puzzle");
                    while (reader.Read())
                    {
                        vGame.GameName = reader.GetString(0);
                        vGame.PublisherName = reader.GetString(1);
                        vGame.PublisherWebsite = reader.GetString(2);
                        vGame.CategoryName = reader.GetString(3);
                        vGame.RatingType = reader.GetString(4);
                    }
                    reader.Close();
                    CloseConnection();
                    Console.WriteLine($"GameName:{vGame.GameName} \n PublisherName:{vGame.PublisherName} \n Website:{vGame.PublisherWebsite} \n Category:{vGame.CategoryName} \n Rating:{vGame.RatingType}");
                    program.Start();
                    break;

                case 5:
                    reader = GetReader("select * from vGames where CategoryName=Crime");
                    while (reader.Read())
                    {
                        vGame.GameName = reader.GetString(0);
                        vGame.PublisherName = reader.GetString(1);
                        vGame.PublisherWebsite = reader.GetString(2);
                        vGame.CategoryName = reader.GetString(3);
                        vGame.RatingType = reader.GetString(4);
                    }
                    reader.Close();
                    CloseConnection();
                    Console.WriteLine($"GameName:{vGame.GameName} \n PublisherName:{vGame.PublisherName} \n Website:{vGame.PublisherWebsite} \n Category:{vGame.CategoryName} \n Rating:{vGame.RatingType}");
                    program.Start();
                    break;

                default:
                    Console.WriteLine("Invalid Choice");
                    program.Start();
                    break;
            }
        }
        public void Search()
        {
            string searchQuery;
            vGame vGame = new vGame();
            Console.WriteLine("Enter Search query for Game Name");
            searchQuery = Console.ReadLine();
            var reader = GetReader($"select * from vGames where GameName like %{searchQuery}%");
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    vGame.GameName = reader.GetString(0);
                    vGame.PublisherName = reader.GetString(1);
                    vGame.PublisherWebsite = reader.GetString(2);
                    vGame.CategoryName = reader.GetString(3);
                    vGame.RatingType = reader.GetString(4);
                }
                reader.Close();
                CloseConnection();
                Console.WriteLine($"GameName:{vGame.GameName} \n PublisherName:{vGame.PublisherName} \n Website:{vGame.PublisherWebsite} \n Category:{vGame.CategoryName} \n Rating:{vGame.RatingType}");
            }
            else
            {
                Console.WriteLine("No Data Found!!!");
            }
        }
    }
}
