﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment2
{
    class Game
    {
        public int GameID { get; set; }
        public string GameName { get; set; }
        public int PublisherId { get; set; }
        public int CategoryId { get; set; }
        public int RatingId { get; set; }
    }
}
