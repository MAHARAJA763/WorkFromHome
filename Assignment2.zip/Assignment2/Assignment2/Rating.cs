﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment2
{
    class Rating
    {
        public int RatingId { get; set; }
        public string RatingType { get; set; }
    }
}
