﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment2
{
    class vGame
    {
        public string GameName { get; set; }
        public string PublisherName { get; set; }
        public string PublisherWebsite { get; set; }
        public string CategoryName { get; set; }
        public string RatingType { get; set; }
    }
}
